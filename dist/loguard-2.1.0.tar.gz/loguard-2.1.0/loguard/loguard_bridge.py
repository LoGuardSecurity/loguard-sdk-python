"""
loguard_bridge.py — мост между Loguard Python SDK и LoGuard kernel firewall.

Когда monitor.blacklist.block_ip() вызывается в SDK,
этот bridge дополнительно блокирует IP на уровне kernel
через Unix socket к loguard-daemon (NF_DROP за 100ns).

Fail-safe: если daemon недоступен — SDK работает как обычно.
Никогда не поднимает исключения.

Usage:
    from loguard.loguard_bridge import get_bridge, configure_bridge

    # Автоматически (singleton):
    bridge = get_bridge()
    bridge.block_ip('1.2.3.4', duration=3600, reason='SQL_INJECTION')

    # Явная настройка:
    bridge = configure_bridge(
        sock_path='/var/run/loguard.sock',
        enabled=True,
    )

    # В monitor.init():
    monitor.init(api_key='lg_live_xxx')
    monitor.init_firewall()  # подключить LoGuard
"""

from __future__ import annotations

import json
import logging
import os
import socket
import threading
from datetime import datetime, timezone
from typing import Any, Dict, Optional

log = logging.getLogger("loguard.bridge")

_DEFAULT_SOCK = "/var/run/loguard.sock"
_TIMEOUT = 1.0  # секунд — не блокируем надолго
_DEFAULT_DURATION = 86400  # 24 часа если не указано


class LoGuardBridge:
    """
    Мост к LoGuard kernel firewall daemon.

    Thread-safe. Fail-safe — никогда не роняет приложение.

    Attributes:
        sock_path:  путь к Unix socket loguard-daemon
        enabled:    если False — все вызовы no-op
    """

    def __init__(
            self,
            sock_path: str = _DEFAULT_SOCK,
            enabled: bool = True,
            auto_detect: bool = True,
            timeout: float = _TIMEOUT,
            token: str = "",
    ):
        self._sock_path = sock_path
        self._enabled = enabled
        self._timeout = timeout
        self._token = token
        self._lock = threading.Lock()
        self._available: Optional[bool] = None

        if auto_detect and enabled:
            self._available = self._check_available()
            if self._available:
                log.info("LoGuard daemon доступен: %s", sock_path)
            else:
                log.debug(
                    "LoGuard daemon недоступен (%s) — kernel block отключён",
                    sock_path,
                )

    # ── Internal ──────────────────────────────────────────────────────────────

    def _request(
            self,
            method: str,
            path: str,
            body: Optional[Dict[str, Any]] = None,
    ) -> Optional[Dict[str, Any]]:
        """Отправить HTTP-over-Unix-socket запрос к daemon."""
        if not self._enabled:
            return None
        if not os.path.exists(self._sock_path):
            return None

        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
                s.settimeout(self._timeout)
                s.connect(self._sock_path)

                token_header = f"X-Loguard-Token: {self._token}\r\n" if self._token else ""

                if body is not None:
                    data = json.dumps(body)
                    req = (
                        f"{method} {path} HTTP/1.1\r\n"
                        f"Host: loguard\r\n"
                        f"Content-Type: application/json\r\n"
                        f"Content-Length: {len(data)}\r\n"
                        f"{token_header}"
                        f"\r\n"
                        f"{data}"
                    )
                else:
                    req = (
                        f"{method} {path} HTTP/1.1\r\n"
                        f"Host: loguard\r\n"
                        f"{token_header}"
                        f"\r\n"
                    )

                s.sendall(req.encode())
                resp = s.recv(8192).decode(errors="replace")

                if "{" in resp:
                    json_start = resp.index("{")
                    return json.loads(resp[json_start:])

        except (OSError, json.JSONDecodeError, Exception) as exc:
            log.debug("LoGuard bridge request error: %r", exc)

        return None

    def _check_available(self) -> bool:
        result = self._request("GET", "/status")
        return result is not None

    # ── Public API ────────────────────────────────────────────────────────────

    def block_ip(
            self,
            ip: str,
            duration: int = _DEFAULT_DURATION,
            reason: str = "",
    ) -> bool:
        """
        Заблокировать IP на kernel уровне (NF_DROP).

        Args:
            ip:       IPv4 адрес в формате "1.2.3.4"
            duration: блокировать на N секунд (по умолчанию 24 часа)
            reason:   причина блокировки (логируется)

        Returns:
            True если daemon подтвердил блокировку, False если нет связи.
            Никогда не поднимает исключения.
        """
        result = self._request("POST", "/block/ip", {
            "ip": ip,
            "duration": duration,
            "reason": reason,
        })
        if result and result.get("ok"):
            log.info(
                "LoGuard kernel block: %s for %ds reason=%r rule_id=%s",
                ip, duration, reason, result.get("rule_id"),
            )
            return True
        return False

    def unblock_ip(self, ip: str) -> bool:
        """
        Разблокировать IP.

        Returns True если успешно.
        """
        result = self._request("POST", "/unblock/ip", {"ip": ip})
        if result and result.get("ok"):
            log.info("LoGuard kernel unblock: %s", ip)
            return True
        return False

    def block_country(self, country: str) -> bool:
        """
        Заблокировать страну через GeoIP.

        Args:
            country: ISO 3166-1 alpha-2 код (например "RU", "CN", "KP")
        """
        result = self._request("POST", "/block/country", {
            "country": country.upper(),
        })
        if result and result.get("ok"):
            log.info(
                "LoGuard GeoIP block: %s (%d total blocked countries)",
                country, result.get("blocked_countries", 0),
            )
            return True
        return False

    def unblock_country(self, country: str) -> bool:
        """Разблокировать страну."""
        result = self._request("POST", "/unblock/country", {
            "country": country.upper(),
        })
        return bool(result and result.get("ok"))

    def get_status(self) -> Optional[Dict[str, Any]]:
        """
        Получить статус daemon.

        Returns dict или None если daemon недоступен:
            {
                "status": "running",
                "rules": 6,
                "connections": 42,
                "geoip_loaded": true,
                "ids_rules": 3
            }
        """
        return self._request("GET", "/status")

    def get_stats(self) -> Optional[Dict[str, Any]]:
        """
        Получить статистику daemon.

        Returns dict или None:
            {
                "rules": 6,
                "connections": 42,
                "ids_alerts": 15,
                "geo_blocked": 100
            }
        """
        return self._request("GET", "/stats")

    def get_rules(self) -> Optional[Dict[str, Any]]:
        """Получить список правил из daemon."""
        return self._request("GET", "/rules")

    def send_alert(
            self,
            ip: str,
            attack_type: str,
            severity: str,
            payload: str = "",
    ) -> bool:
        """
        Отправить алерт в daemon (для логирования и IDS статистики).

        Args:
            ip:          атакующий IP
            attack_type: тип атаки ("SQL_INJECTION", "XSS", "PATH_TRAVERSAL")
            severity:    "CRITICAL", "HIGH", "MEDIUM", "LOW"
            payload:     фрагмент payload (первые 200 символов)
        """
        result = self._request("POST", "/alert", {
            "ip": ip,
            "type": attack_type,
            "severity": severity,
            "payload": payload[:200] if payload else "",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        return bool(result and result.get("ok"))

    def is_available(self) -> bool:
        """Проверить доступен ли daemon прямо сейчас."""
        return self._check_available()

    # ── Properties ────────────────────────────────────────────────────────────

    @property
    def enabled(self) -> bool:
        return self._enabled

    @enabled.setter
    def enabled(self, value: bool) -> None:
        self._enabled = value
        log.info("LoGuard bridge %s", "включён" if value else "отключён")

    @property
    def sock_path(self) -> str:
        return self._sock_path

    def __repr__(self) -> str:
        return (
            f"LoGuardBridge(sock={self._sock_path!r}, "
            f"enabled={self._enabled}, "
            f"available={self._available})"
        )


# ── Singleton ──────────────────────────────────────────────────────────────────

_bridge: Optional[LoGuardBridge] = None
_bridge_lock = threading.Lock()


def get_bridge() -> LoGuardBridge:
    """
    Получить singleton bridge (ленивая инициализация из ENV).

    ENV variables:
        LOGUARD_SOCK           путь к socket (default: /var/run/loguard.sock)
        LOGUARD_KERNEL_BLOCK   "true"/"false" (default: "true")
        LOGUARD_BLOCK_TIMEOUT  timeout в секундах (default: 1.0)
    """
    global _bridge
    if _bridge is None:
        with _bridge_lock:
            if _bridge is None:
                sock = os.environ.get("LOGUARD_SOCK", _DEFAULT_SOCK)
                enabled = os.environ.get("LOGUARD_KERNEL_BLOCK", "true").lower() \
                          not in ("false", "0", "no")
                timeout = float(os.environ.get("LOGUARD_BLOCK_TIMEOUT", "1.0"))
                token = os.environ.get("LOGUARD_DAEMON_TOKEN", "")  # ← NEW
                _bridge = LoGuardBridge(
                    sock_path=sock,
                    enabled=enabled,
                    timeout=timeout,
                    token=token,
                )
    return _bridge


def configure_bridge(
        sock_path: str = _DEFAULT_SOCK,
        enabled: bool = True,
        timeout: float = _TIMEOUT,
        token: str = "",  # ← NEW
) -> LoGuardBridge:
    """
    Явно настроить bridge (вызывать после monitor.init()).

    Пример:
        monitor.init(api_key="lg_live_xxx")
        configure_bridge(sock_path="/var/run/loguard.sock", enabled=True)

    Returns настроенный singleton bridge.
    """
    global _bridge
    with _bridge_lock:
        _bridge = LoGuardBridge(
            sock_path=sock_path,
            enabled=enabled,
            timeout=timeout,
            token=token,
        )
    return _bridge


def _calc_duration(expires_at: Optional[str]) -> int:
    """
    Рассчитать duration в секундах из ISO timestamp expires_at.

    Returns:
        Количество секунд до expires_at, минимум 60.
        Если expires_at=None → _DEFAULT_DURATION (24 часа).
    """
    if not expires_at:
        return _DEFAULT_DURATION
    try:
        exp = datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
        now = datetime.now(timezone.utc)
        delta = int((exp - now).total_seconds())
        return max(60, delta)
    except Exception:
        return _DEFAULT_DURATION
