from __future__ import annotations

import logging
import threading
from typing import Callable, Optional, Sequence, Set

from ..monitor import monitor as _monitor
from ..exceptions import LogguardError, LogguardNotInitializedError

log = logging.getLogger("logguard.django")

# A starting point, not a guarantee of completeness. These are header
# names that have historically carried real-world RCE payloads — see the
# matching note in integrations/fastapi.py for the full rationale.
KNOWN_EXPLOIT_HEADERS: tuple[str, ...] = (
    "user-agent",
    "referer",
    "x-beresource",
    "x-anonresource-backend",
)


def _header_to_meta_key(header_name: str) -> str:
    """
    Django exposes incoming headers through request.META using keys like
    HTTP_USER_AGENT — dashes become underscores, everything uppercase, with
    an HTTP_ prefix. This converts "User-Agent" into that lookup key.
    """
    return "HTTP_" + header_name.upper().replace("-", "_")


class LogguardMiddleware:
    """
    Django middleware that automatically tracks HTTP requests and can
    optionally enforce your blacklist on every incoming request.

    Setup in settings.py:
        MIDDLEWARE = [
            "logguard.integrations.django.LogguardMiddleware",
            ...  # keep it early so the blacklist check runs before your views
        ]

    Optional settings.py configuration:
        LOGGUARD_ENFORCE_BLACKLIST = True        # reject blacklisted IPs
        LOGGUARD_TRACK_ALL         = False       # track every request, not just errors
        LOGGUARD_TRACK_STATUSES    = {400, 401, 403, 404, 429, 500, 502, 503}
        LOGGUARD_TRACK_HEADERS     = None        # see below — off by default

    And during app startup (for example in AppConfig.ready()):
        from logguard import monitor
        monitor.init(api_key="lg_live_xxx", env="production")

    Blocked IPs get back an HTTP 403 JSON response.

    ── Forwarding request headers (optional, off by default) ───────────────

    A handful of severe vulnerabilities — ShellShock, ProxyLogon — only
    show up inside specific HTTP headers, never in the URL path or the
    request body. Out of the box, LoGuard doesn't look at any of your
    request headers beyond what it already needs internally.

    If you'd like LoGuard's detectors to also scan specific headers for
    known exploit patterns, opt in by naming exactly which ones to send:

        from logguard.integrations.django import KNOWN_EXPLOIT_HEADERS

        # settings.py
        LOGGUARD_TRACK_HEADERS = KNOWN_EXPLOIT_HEADERS
        # or pick your own:
        # LOGGUARD_TRACK_HEADERS = ["User-Agent", "X-My-Custom-Header"]

    You're always in control of exactly what gets sent. Leaving this unset
    (the default) means nothing is collected — no surprises, no implicit
    data sharing.

    Please never list "Authorization", "Cookie", "X-Api-Key", or any
    header that might carry credentials, session tokens, or personal data.
    LoGuard forwards whatever you name here verbatim — it has no way to
    tell a sensitive header from a harmless one, so that judgment call is
    yours to make.
    """

    def __init__(
        self,
        get_response: Callable,
        *,
        track_statuses: Optional[Set[int]] = None,
        enforce_blacklist: Optional[bool] = None,
        track_all: Optional[bool] = None,
        track_headers: Optional[Sequence[str]] = None,
    ):
        self.get_response = get_response

        # Fall back to Django settings when these aren't passed explicitly.
        try:
            from django.conf import settings as _ds
            _enforce = getattr(_ds, "LOGGUARD_ENFORCE_BLACKLIST", False)
            _track_all = getattr(_ds, "LOGGUARD_TRACK_ALL", False)
            _statuses = getattr(_ds, "LOGGUARD_TRACK_STATUSES", None)
            _headers = getattr(_ds, "LOGGUARD_TRACK_HEADERS", None)
        except Exception:
            _enforce = False
            _track_all = False
            _statuses = None
            _headers = None

        self._enforce_blacklist = enforce_blacklist if enforce_blacklist is not None else _enforce
        self._track_all         = track_all if track_all is not None else _track_all
        self._track_statuses    = track_statuses or _statuses or {
            400, 401, 403, 404, 429, 500, 502, 503
        }

        chosen_headers = track_headers if track_headers is not None else _headers
        self._track_headers: tuple[str, ...] = (
            tuple(h.lower() for h in chosen_headers) if chosen_headers else ()
        )

    def _collect_tracked_headers(self, request) -> dict:
        """
        Returns only the headers you opted into via track_headers /
        LOGGUARD_TRACK_HEADERS — an empty dict if you never configured it.
        Uses the same output shape as the FastAPI integration (lowercase
        header name mapped to a truncated value), so server-side detectors
        don't need to know which framework sent the event.
        """
        if not self._track_headers:
            return {}
        collected = {}
        for name in self._track_headers:
            meta_key = _header_to_meta_key(name)
            val = request.META.get(meta_key)
            if val:
                collected[name] = str(val)[:512]
        return collected

    def __call__(self, request):
        from django.http import JsonResponse

        ip = (
            request.META.get("HTTP_X_FORWARDED_FOR", "").split(",")[0].strip()
            or request.META.get("REMOTE_ADDR", "unknown")
        )

        # ── Blacklist check, before the request reaches your views ─────────
        if self._enforce_blacklist:
            try:
                result = _monitor.blacklist.check(type="ip", value=ip)
                if result.get("blacklisted") and result.get("action") == "block":
                    log.info(
                        "logguard_blocked ip=%s reason=%s",
                        ip, result.get("reason", "blacklisted"),
                    )
                    return JsonResponse(
                        {"detail": "Forbidden", "reason": result.get("reason", "blacklisted")},
                        status=403,
                    )
            except LogguardNotInitializedError:
                log.warning("LogguardMiddleware: monitor not initialized")
            except LogguardError as e:
                log.debug("LogguardMiddleware blacklist check failed: %r", e)

        # ── Let the request through ─────────────────────────────────────────
        response = self.get_response(request)

        # ── Track events of interest ────────────────────────────────────────
        should_track = (
            self._track_all
            or response.status_code in self._track_statuses
        )

        if should_track:
            user_id = None
            try:
                if getattr(request, "user", None) and request.user.is_authenticated:
                    user_id = str(request.user.pk)
            except Exception:
                pass

            event_type = "login_failed" if response.status_code == 401 else "http_request"

            meta = {
                "method": request.method,
            }
            tracked = self._collect_tracked_headers(request)
            if tracked:
                meta["headers"] = tracked

            # fire_and_forget uses the SDK's internal queue, so this never
            # spins up a new thread per request.
            try:
                _monitor.event_fire_and_forget(
                    type=event_type,
                    ip=ip,
                    path=request.path,
                    status_code=response.status_code,
                    user_id=user_id,
                    meta=meta,
                )
            except LogguardNotInitializedError:
                log.warning("LogguardMiddleware: monitor not initialized")
            except LogguardError as e:
                log.debug("LogguardMiddleware track failed: %r", e)

        return response