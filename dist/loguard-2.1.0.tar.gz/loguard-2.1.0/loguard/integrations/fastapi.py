from __future__ import annotations

import logging
from typing import Callable, Optional, Sequence, Set

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from ..monitor import monitor as _monitor
from ..exceptions import LogguardError, LogguardNotInitializedError

log = logging.getLogger("loguard.fastapi")

# A starting point, not a guarantee of completeness. These are header
# names that have historically carried real-world RCE payloads:
#
#   User-Agent              ShellShock (CVE-2014-6271) — the exploit lives
#                            inside the UA string itself.
#   Referer                 Same exploit family, alternate carrier header.
#   X-BEResource             ProxyLogon (CVE-2021-26855) — Exchange Server
#   X-AnonResource-Backend   SSRF chain, same vulnerability class.
#
# New attack techniques targeting other headers appear over time, so treat
# this list as a sensible default, not a final answer.
KNOWN_EXPLOIT_HEADERS: tuple[str, ...] = (
    "user-agent",
    "referer",
    "x-beresource",
    "x-anonresource-backend",
)


class LoGuardMiddleware(BaseHTTPMiddleware):
    """
    FastAPI / Starlette middleware that automatically tracks HTTP errors
    and can optionally enforce your blacklist on every incoming request.

    Basic setup:
        from fastapi import FastAPI
        from logguard import monitor
        from logguard.integrations.fastapi import LoGuardMiddleware

        app = FastAPI()
        monitor.init(api_key="lg_live_xxx", env="production")

        app.add_middleware(
            LoGuardMiddleware,
            track_statuses={400, 401, 403, 404, 429, 500, 502, 503},
            enforce_blacklist=True,  # reject blacklisted IPs before they reach your routes
        )

    When blacklist enforcement is on, blocked IPs/users get back:
        HTTP 403 {"detail": "Forbidden", "reason": "..."}
    Flagged (but not blocked) entries still pass through — the request is
    just marked for visibility, not rejected.

    ── Forwarding request headers (optional, off by default) ───────────────

    A handful of severe vulnerabilities — ShellShock, ProxyLogon — only
    show up inside specific HTTP headers, never in the URL path or the
    request body. Out of the box, LoGuard doesn't look at any of your
    request headers beyond what it already needs internally (the
    X-Forwarded-For value, used solely to resolve the visitor's real IP —
    that header's content is never forwarded to LoGuard as data).

    If you'd like LoGuard's detectors to also scan specific headers for
    known exploit patterns, opt in by naming exactly which ones to send:

        from logguard.integrations.fastapi import KNOWN_EXPLOIT_HEADERS

        app.add_middleware(
            LoGuardMiddleware,
            track_headers=KNOWN_EXPLOIT_HEADERS,  # the curated starter set above
            # or pick your own:
            # track_headers=["User-Agent", "Referer", "X-My-Custom-Header"],
        )

    You're always in control of exactly what gets sent. Leaving
    track_headers unset (the default) means nothing is collected — no
    surprises, no implicit data sharing.

    Please never list "Authorization", "Cookie", "X-Api-Key", or any
    header that might carry credentials, session tokens, or personal data.
    LoGuard forwards whatever you name here verbatim — it has no way to
    tell a sensitive header from a harmless one, so that judgment call is
    yours to make.
    """

    def __init__(
        self,
        app,
        *,
        track_statuses: Optional[Set[int]] = None,
        enforce_blacklist: bool = False,
        get_user_id: Optional[Callable[[Request], Optional[str]]] = None,
        track_headers: Optional[Sequence[str]] = None,
    ):
        super().__init__(app)
        self._track_statuses = track_statuses or {400, 401, 403, 404, 429, 500, 502, 503}
        self._enforce_blacklist = enforce_blacklist
        self._get_user_id = get_user_id
        # Normalized once up front so header lookups stay simple below.
        self._track_headers: tuple[str, ...] = (
            tuple(h.lower() for h in track_headers) if track_headers else ()
        )

    def _collect_tracked_headers(self, request: Request) -> dict:
        """
        Returns only the headers you opted into via track_headers — an
        empty dict if you never set it. Each value is truncated defensively
        so a single oversized header can't bloat the payload.
        """
        if not self._track_headers:
            return {}
        collected = {}
        for name in self._track_headers:
            val = request.headers.get(name)
            if val is not None:
                collected[name] = val[:512]
        return collected

    async def dispatch(self, request: Request, call_next) -> Response:
        ip = (
            (request.headers.get("x-forwarded-for") or "").split(",")[0].strip()
            or (request.client.host if request.client else "unknown")
        )

        # ── Blacklist check, before the request reaches your routes ────────
        if self._enforce_blacklist:
            try:
                result = await _monitor.blacklist.acheck(type="ip", value=ip)
                if result.get("blacklisted") and result.get("action") == "block":
                    return JSONResponse(
                        status_code=403,
                        content={"detail": "Forbidden", "reason": result.get("reason", "blacklisted")},
                    )
            except LogguardNotInitializedError:
                log.warning("LoGuardMiddleware: monitor not initialized")
            except LogguardError as e:
                log.debug("LoGuardMiddleware blacklist check failed: %r", e)

        # ── Let the request through ─────────────────────────────────────────
        response = await call_next(request)

        # ── Track errors of interest ────────────────────────────────────────
        if response.status_code in self._track_statuses:
            try:
                user_id = None
                if self._get_user_id:
                    try:
                        user_id = self._get_user_id(request)
                    except Exception:
                        pass

                event_type = "login_failed" if response.status_code == 401 else "http_error"

                meta = {}
                tracked = self._collect_tracked_headers(request)
                if tracked:
                    meta["headers"] = tracked

                await _monitor.aevent(
                    type=event_type,
                    ip=ip,
                    path=request.url.path,
                    status_code=response.status_code,
                    user_id=user_id,
                    meta=meta or None,
                )
            except LogguardNotInitializedError:
                log.warning("LogguardMiddleware: monitor not initialized")
            except LogguardError as e:
                log.debug("LogguardMiddleware track failed: %r", e)

        return response