"""
loguard/shield.py

ShieldMiddleware — Anti-Tor/VPN/Proxy/Phishing защита для FastAPI/Starlette.

Архитектура:
- Клиент не знает URL sentinel — всё берётся из monitor
- Ed25519 верификация каждого ответа sentinel
- LRU кэш 10k IP, TTL 5 мин
- Circuit breaker (5 ошибок → open на 60 сек)
- Fail-open/closed режим
- Anti-spoof: реальный IP только из trusted proxies

Использование:
    from loguard import monitor, ShieldMiddleware
    monitor.init(api_key="lg_live_xxx")
    app.add_middleware(ShieldMiddleware)

Расширенное:
    app.add_middleware(
        ShieldMiddleware,
        block_tor=True,
        block_vpn=True,
        block_proxy=True,
        fail_open=True,
        whitelist=["192.168.0.0/24"],
    )
"""
from __future__ import annotations

import ipaddress
import logging
import time
import threading
from collections import OrderedDict
from typing import Any, Callable, Dict, List, Optional, Tuple

import httpx
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
import base64

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response, JSONResponse

log = logging.getLogger("loguard.shield")

# ── LRU Cache ──────────────────────────────────────────────────────────────────

class _LRUCache:
    """Thread-safe LRU кэш с TTL."""

    def __init__(self, max_size: int = 10_000, ttl: float = 300.0):
        self._cache: OrderedDict[str, Tuple[Any, float]] = OrderedDict()
        self._max   = max_size
        self._ttl   = ttl
        self._lock  = threading.Lock()

    def get(self, key: str) -> Optional[Any]:
        with self._lock:
            entry = self._cache.get(key)
            if not entry:
                return None
            value, exp = entry
            if time.monotonic() > exp:
                del self._cache[key]
                return None
            self._cache.move_to_end(key)
            return value

    def set(self, key: str, value: Any) -> None:
        with self._lock:
            if key in self._cache:
                self._cache.move_to_end(key)
            self._cache[key] = (value, time.monotonic() + self._ttl)
            while len(self._cache) > self._max:
                self._cache.popitem(last=False)

    def clear(self) -> None:
        with self._lock:
            self._cache.clear()


# ── Circuit Breaker ────────────────────────────────────────────────────────────

class _CircuitBreaker:
    """Circuit breaker для sentinel соединения."""

    def __init__(self, threshold: int = 5, timeout: float = 60.0):
        self._threshold  = threshold
        self._timeout    = timeout
        self._failures   = 0
        self._opened_at  = 0.0
        self._lock       = threading.Lock()

    def is_open(self) -> bool:
        with self._lock:
            if self._failures < self._threshold:
                return False
            if time.monotonic() - self._opened_at > self._timeout:
                self._failures = 0  # half-open
                return False
            return True

    def record_success(self) -> None:
        with self._lock:
            self._failures = 0

    def record_failure(self) -> None:
        with self._lock:
            self._failures += 1
            if self._failures >= self._threshold:
                self._opened_at = time.monotonic()
                log.warning("shield_circuit_opened failures=%d", self._failures)


# ── IP helpers ─────────────────────────────────────────────────────────────────

_PRIVATE_NETWORKS = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fc00::/7"),
]


def _is_private(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(ip)
        return any(addr in net for net in _PRIVATE_NETWORKS)
    except ValueError:
        return False


def _is_whitelisted(ip: str, whitelist: List[str]) -> bool:
    try:
        addr = ipaddress.ip_address(ip)
        for entry in whitelist:
            try:
                net = ipaddress.ip_network(entry, strict=False) if "/" in entry \
                      else ipaddress.ip_network(f"{entry}/32", strict=False)
                if addr in net:
                    return True
            except ValueError:
                pass
    except ValueError:
        pass
    return False


def _get_real_ip(request: Request, trusted_proxies: List[str]) -> str:
    """Извлечь реальный IP с защитой от X-Forwarded-For спуфинга."""
    client_ip = request.client.host if request.client else "127.0.0.1"

    if client_ip in trusted_proxies:
        xff = request.headers.get("X-Forwarded-For", "")
        if xff:
            candidate = xff.split(",")[0].strip()
            try:
                ipaddress.ip_address(candidate)
                return candidate
            except ValueError:
                pass

    return client_ip


# ── Ed25519 Verification ───────────────────────────────────────────────────────

def _verify_response(result: Dict[str, Any], public_key: Ed25519PublicKey) -> bool:
    """Верифицировать Ed25519 подпись ответа sentinel."""
    try:
        verdict   = str(result.get("verdict", "")).lower()
        score     = float(result.get("risk_score", 0))
        timestamp = int(result.get("timestamp", 0))
        nonce     = str(result.get("nonce", ""))
        sig_b64   = str(result.get("signature", ""))

        if not sig_b64:
            return False

        # Проверить timestamp (не старше 5 мин)
        if abs(time.time() - timestamp) > 300:
            log.warning("shield_response_expired timestamp=%d", timestamp)
            return False

        # Воссоздать payload как в Rust
        # Rust f32 форматирование: 0.0 → "0", 9.5 → "9.5"
        score_str = str(int(score)) if score == int(score) else str(score)
        payload = f"{verdict}|{score_str}|{timestamp}|{nonce}".encode()
        sig     = base64.b64decode(sig_b64)
        public_key.verify(sig, payload)
        return True

    except Exception as e:
        log.warning("shield_verify_failed err=%r", e)
        return False


def _fetch_public_key(sentinel_url: str, api_key: str) -> Optional[Ed25519PublicKey]:
    """Скачать публичный ключ с sentinel."""
    try:
        with httpx.Client(timeout=5.0) as client:
            resp = client.get(
                f"{sentinel_url}/api/shield/public-key",
                headers={"X-API-Key": api_key},
            )
            data    = resp.json()
            key_b64 = data.get("public_key", "")
            key_bytes = base64.b64decode(key_b64)
            return Ed25519PublicKey.from_public_bytes(key_bytes)
    except Exception as e:
        log.error("shield_fetch_public_key_failed err=%r", e)
        return None


# ── Sentinel Client ────────────────────────────────────────────────────────────

class SentinelClient:
    """HTTP клиент для loguard-sentinel с Ed25519 верификацией."""

    def __init__(
        self,
        sentinel_url: str,
        api_key:      str,
        timeout:      float = 2.0,
    ):
        self._url       = sentinel_url.rstrip("/")
        self._api_key   = api_key
        self._timeout   = timeout
        self._cache     = _LRUCache(max_size=10_000, ttl=300.0)
        self._cb        = _CircuitBreaker(threshold=5, timeout=60.0)
        self._pubkey:   Optional[Ed25519PublicKey] = None
        self._pubkey_id: str = ""
        self._lock      = threading.Lock()

    def _ensure_public_key(self) -> bool:
        """Загрузить публичный ключ если ещё нет."""
        if self._pubkey:
            return True
        with self._lock:
            if self._pubkey:
                return True
            key = _fetch_public_key(self._url, self._api_key)
            if key:
                self._pubkey = key
                log.info("shield_public_key_loaded")
                return True
        return False

    def check(self, ip: str) -> Dict[str, Any]:
        """Проверить IP через sentinel."""
        # Кэш
        cached = self._cache.get(ip)
        if cached:
            return {**cached, "cached": True}

        # Circuit breaker
        if self._cb.is_open():
            return {"verdict": "allow", "cached": False, "circuit_open": True}

        # Загрузить публичный ключ
        if not self._ensure_public_key():
            self._cb.record_failure()
            return {"verdict": "allow", "cached": False, "error": "no_public_key"}

        try:
            with httpx.Client(timeout=self._timeout) as client:
                resp = client.post(
                    f"{self._url}/api/shield/check",
                    json={"ip": ip},
                    headers={
                        "X-Api-Key":      self._api_key,
                        "Content-Type":   "application/json",
                    },
                )
                result = resp.json()

            # Верифицировать подпись
            if not _verify_response(result, self._pubkey):
                log.error("shield_invalid_signature ip=%s — blocking", ip)
                return {"verdict": "block", "reasons": ["invalid_signature"], "risk_score": 10.0}

            self._cb.record_success()
            self._cache.set(ip, result)
            return result

        except Exception as e:
            self._cb.record_failure()
            log.warning("shield_check_error ip=%s err=%r", ip, e)
            return {"verdict": "allow", "cached": False, "error": str(e)}

    def clear_cache(self) -> None:
        self._cache.clear()


# ── Middleware ─────────────────────────────────────────────────────────────────

class ShieldMiddleware(BaseHTTPMiddleware):
    """
    Anti-Tor/VPN/Proxy/Phishing middleware для FastAPI/Starlette.

    Берёт api_key и sentinel_url из monitor автоматически.
    Клиент не знает URL sentinel.
    """

    def __init__(
        self,
        app,
        block_tor:       bool = True,
        block_vpn:       bool = True,
        block_proxy:     bool = True,
        block_phishing:  bool = True,
        fail_open:       bool = True,
        whitelist:       Optional[List[str]] = None,
        trusted_proxies: Optional[List[str]] = None,
        timeout:         float = 2.0,
    ):
        super().__init__(app)
        self.block_tor       = block_tor
        self.block_vpn       = block_vpn
        self.block_proxy     = block_proxy
        self.block_phishing  = block_phishing
        self.fail_open       = fail_open
        self.whitelist       = whitelist or []
        self.trusted_proxies = trusted_proxies or []

        # Взять из monitor
        from .monitor import monitor as _monitor
        # Клиент идёт через loguard main — не знает URL sentinel
        sentinel_url = getattr(_monitor, "_base_url", "https://api.logguard.io")
        api_key      = getattr(_monitor, "_api_key", "") or ""

        self._client = SentinelClient(
            sentinel_url=sentinel_url,
            api_key=api_key,
            timeout=timeout,
        )

        log.info(
            "shield_ready block_tor=%s block_vpn=%s block_proxy=%s fail_open=%s",
            block_tor, block_vpn, block_proxy, fail_open,
        )

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        ip = _get_real_ip(request, self.trusted_proxies)

        # Пропустить приватные IP и whitelist
        if _is_private(ip) or _is_whitelisted(ip, self.whitelist):
            return await call_next(request)

        # Проверить через sentinel
        try:
            result = self._client.check(ip)
        except Exception as e:
            log.error("shield_dispatch_error ip=%s err=%r", ip, e)
            if self.fail_open:
                return await call_next(request)
            return self._deny(ip, "sentinel_error")

        # Если ошибка соединения — fail-open/closed
        if "error" in result or result.get("circuit_open"):
            if self.fail_open:
                return await call_next(request)
            return self._deny(ip, "sentinel_unavailable")

        verdict = str(result.get("verdict", "allow")).lower()
        reasons = result.get("reasons", [])

        if verdict != "block":
            return await call_next(request)

        # Проверить что именно блокировать по настройкам
        block_reason = self._should_block(reasons)
        if not block_reason:
            return await call_next(request)

        log.warning(
            "shield_blocked ip=%s reason=%s score=%.1f cached=%s",
            ip, block_reason,
            result.get("risk_score", 0),
            result.get("cached", False),
        )

        # Логировать в LoGuard
        self._log_block(ip, block_reason, result)

        return self._deny(ip, block_reason)

    def _should_block(self, reasons: List) -> Optional[str]:
        """Вернуть причину блокировки или None если не нужно блокировать."""
        reason_map = {
            "tor_exit_node":   self.block_tor,
            "known_vpn":       self.block_vpn,
            "open_proxy":      self.block_proxy,
            "phishing_domain": self.block_phishing,
            "malicious_domain": self.block_phishing,
        }
        for reason in reasons:
            r = reason if isinstance(reason, str) else str(reason)
            # Обработать dict формат {"custom": "manual"}
            if isinstance(reason, dict):
                r = list(reason.keys())[0] if reason else "custom"
            if reason_map.get(r, True):  # неизвестные причины → блокировать
                return r
        return None

    def _deny(self, ip: str, reason: str) -> Response:
        return JSONResponse(
            status_code=403,
            content={
                "error":   "access_denied",
                "reason":  reason,
                "message": "Access denied by LoGuard Shield",
            },
        )

    def _log_block(self, ip: str, reason: str, result: Dict) -> None:
        """Логировать блокировку в LoGuard async (fire-and-forget)."""
        try:
            from .monitor import monitor as _monitor
            if _monitor.is_initialized:
                _monitor.event_fire_and_forget(
                    type=f"shield_blocked_{reason}",
                    ip=ip,
                    path="/shield/check",
                    status_code=403,
                    meta={
                        "reason":     reason,
                        "risk_score": result.get("risk_score", 0),
                        "reasons":    result.get("reasons", []),
                    },
                )
        except Exception:
            pass  # никогда не падаем из-за логирования