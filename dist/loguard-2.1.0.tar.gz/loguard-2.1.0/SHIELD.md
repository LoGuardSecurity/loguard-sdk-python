# LoGuard Shield

Anti-Tor/VPN/Proxy/Phishing middleware для FastAPI/Django/Flask.

## Установка

```bash
pip install loguard
```

## Использование

### FastAPI

```python
from loguard import monitor, ShieldMiddleware

monitor.init(api_key="lg_live_xxx")
app.add_middleware(ShieldMiddleware)
```

### Расширенная настройка

```python
app.add_middleware(
    ShieldMiddleware,
    block_tor=True,
    block_vpn=True,
    block_proxy=True,
    fail_open=True,
    whitelist=["192.168.0.0/24"],
    trusted_proxies=["10.0.0.1"],
)
```

### Django

```python
MIDDLEWARE = ["loguard.shield.ShieldMiddleware", ...]
LOGUARD = {"API_KEY": "lg_live_xxx"}
```

## Тарифы

| Фича | Pro | Business | Enterprise |
|------|-----|----------|-----------|
| Anti-Tor | ✅ | ✅ | ✅ |
| Anti-VPN | ✅ | ✅ | ✅ |
| Anti-Proxy | ❌ | ✅ | ✅ |
| Phishing | ❌ | ✅ | ✅ |
| Kernel Firewall | ❌ | ❌ | ✅ |

## Безопасность

- Ed25519 верификация каждого ответа sentinel
- LRU кэш 10k IP, TTL 5 мин
- Circuit breaker (5 ошибок → 60 сек пауза)
- Anti-spoof защита (X-Forwarded-For только от trusted proxies)
