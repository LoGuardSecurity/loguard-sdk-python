"""
Тесты ShieldMiddleware и SentinelClient.

Запуск с sentinel напрямую:
    SENTINEL_URL=http://localhost:9020 SENTINEL_API_KEY=dev_key pytest tests/test_shield.py

Запуск через loguard main:
    SENTINEL_URL=http://localhost:8000 SENTINEL_API_KEY=lg_xxx pytest tests/test_shield.py
"""
import os
import pytest
import sys
sys.path.insert(0, '/Users/admin/PythonProjects/loguard_sdk')

from loguard.shield import SentinelClient, _is_private, _is_whitelisted

SENTINEL_URL = os.environ.get("SENTINEL_URL", "")
API_KEY      = os.environ.get("SENTINEL_API_KEY", "")

skip_integration = pytest.mark.skipif(
    not API_KEY or not SENTINEL_URL,
    reason="SENTINEL_URL or SENTINEL_API_KEY not set"
)


@pytest.fixture(scope="module")
def client():
    c = SentinelClient(SENTINEL_URL, API_KEY)
    if SENTINEL_URL and API_KEY:
        c._ensure_public_key()
    return c


@pytest.fixture(autouse=True)
def reset_cb(client):
    client._cb._failures = 0
    yield


class TestSentinelClient:

    @skip_integration
    def test_allow_google_dns(self, client):
        client._cache.clear()
        r = client.check("8.8.8.8")
        assert r["verdict"] == "allow"
        assert "risk_score" in r

    @skip_integration
    def test_tor_exit_response(self, client):
        client._cache.clear()
        r = client.check("185.220.101.45")
        assert r["verdict"] in ("allow", "block")
        assert "risk_score" in r

    @skip_integration
    def test_cache_works(self, client):
        client._cache.clear()
        client.check("9.9.9.9")
        r = client.check("9.9.9.9")
        assert r.get("cached") is True

    @skip_integration
    def test_signature_present(self, client):
        client._cache.clear()
        r = client.check("1.1.1.1")
        assert "signature" in r
        assert "timestamp" in r
        assert "nonce" in r

    @skip_integration
    def test_cached_has_signature(self, client):
        client._cache.clear()
        client.check("2.2.2.2")
        r = client.check("2.2.2.2")
        assert r.get("cached") is True
        assert "signature" in r


class TestIPHelpers:

    def test_private_ips(self):
        assert _is_private("192.168.1.1") is True
        assert _is_private("10.0.0.1")    is True
        assert _is_private("127.0.0.1")   is True
        assert _is_private("8.8.8.8")     is False

    def test_whitelist_cidr(self):
        assert _is_whitelisted("192.168.1.5", ["192.168.1.0/24"]) is True
        assert _is_whitelisted("8.8.8.8",     ["192.168.1.0/24"]) is False

    def test_whitelist_exact(self):
        assert _is_whitelisted("10.0.0.1", ["10.0.0.1"]) is True
        assert _is_whitelisted("10.0.0.2", ["10.0.0.1"]) is False

    def test_whitelist_empty(self):
        assert _is_whitelisted("8.8.8.8", []) is False


class TestShieldPublicAPI:

    def test_import_shield(self):
        from loguard import ShieldMiddleware
        assert ShieldMiddleware is not None

    def test_sentinel_client_not_exported(self):
        with pytest.raises(ImportError):
            from loguard import SentinelClient

    @skip_integration
    def test_middleware_fastapi(self):
        from loguard import ShieldMiddleware, monitor
        monitor._api_key    = API_KEY
        monitor._shield_url = SENTINEL_URL
        from fastapi import FastAPI
        app = FastAPI()
        app.add_middleware(ShieldMiddleware)
        assert True
