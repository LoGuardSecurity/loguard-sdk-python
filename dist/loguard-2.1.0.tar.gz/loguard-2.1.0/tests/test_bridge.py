"""
tests/test_bridge.py — unit тесты LoGuardBridge

Запуск:
    pytest tests/test_bridge.py -v
    pytest tests/test_bridge.py -v -k "not integration"

Интеграционные тесты (нужен запущенный daemon):
    pytest tests/test_bridge.py -v -m integration
"""

import json
import os
import socket
import threading

import pytest

from loguard.loguard_bridge import (
    LoGuardBridge,
    _calc_duration,
    configure_bridge,
    get_bridge,
    _DEFAULT_SOCK,
    _DEFAULT_DURATION,
)
import loguard.loguard_bridge as _lb_module


# ── Fixtures ───────────────────────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def reset_singleton():
    """Сбрасывать singleton перед каждым тестом."""
    _lb_module._bridge = None
    yield
    _lb_module._bridge = None


@pytest.fixture
def bridge_disabled():
    return LoGuardBridge(enabled=False, auto_detect=False)


@pytest.fixture
def bridge_no_sock():
    return LoGuardBridge(
        sock_path="/tmp/nonexistent_loguard_test.sock",
        auto_detect=False,
    )


def make_mock_response(body: dict) -> bytes:
    data = json.dumps(body)
    return (
        f"HTTP/1.1 200 OK\r\n"
        f"Content-Type: application/json\r\n"
        f"Content-Length: {len(data)}\r\n"
        f"\r\n"
        f"{data}"
    ).encode()


# ── Тесты инициализации ────────────────────────────────────────────────────────

class TestInit:
    def test_disabled(self):
        b = LoGuardBridge(enabled=False, auto_detect=False)
        assert b.enabled is False

    def test_enabled_default(self):
        b = LoGuardBridge(auto_detect=False)
        assert b.enabled is True

    def test_sock_path(self):
        b = LoGuardBridge(sock_path="/custom/path.sock", auto_detect=False)
        assert b.sock_path == "/custom/path.sock"

    def test_repr(self):
        b = LoGuardBridge(auto_detect=False)
        r = repr(b)
        assert "LoGuardBridge" in r
        assert "enabled=True" in r

    def test_auto_detect_no_sock(self):
        b = LoGuardBridge(
            sock_path="/tmp/no_such_loguard.sock",
            auto_detect=True,
        )
        assert b._available is False


# ── Тесты fail-safe ────────────────────────────────────────────────────────────

class TestFailSafe:
    def test_block_ip_disabled(self, bridge_disabled):
        assert bridge_disabled.block_ip("1.2.3.4") is False

    def test_block_ip_no_sock(self, bridge_no_sock):
        assert bridge_no_sock.block_ip("1.2.3.4") is False

    def test_unblock_ip_no_sock(self, bridge_no_sock):
        assert bridge_no_sock.unblock_ip("1.2.3.4") is False

    def test_block_country_no_sock(self, bridge_no_sock):
        assert bridge_no_sock.block_country("RU") is False

    def test_get_stats_no_sock(self, bridge_no_sock):
        assert bridge_no_sock.get_stats() is None

    def test_get_status_no_sock(self, bridge_no_sock):
        assert bridge_no_sock.get_status() is None

    def test_is_available_no_sock(self, bridge_no_sock):
        assert bridge_no_sock.is_available() is False

    def test_send_alert_no_sock(self, bridge_no_sock):
        assert bridge_no_sock.send_alert(
            "1.2.3.4", "SQL_INJECTION", "HIGH", "UNION SELECT"
        ) is False

    def test_multiple_calls_no_crash(self, bridge_no_sock):
        for _ in range(1000):
            bridge_no_sock.block_ip("1.2.3.4")
            bridge_no_sock.get_stats()


# ── Тесты с mock socket ────────────────────────────────────────────────────────

class TestMockSocket:
    def _make_bridge_with_mock(self, response_body: dict):
        sock_path = "/tmp/test_loguard_mock.sock"
        try:
            os.unlink(sock_path)
        except FileNotFoundError:
            pass

        server_sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        server_sock.bind(sock_path)
        server_sock.listen(1)
        server_sock.settimeout(2.0)
        response = make_mock_response(response_body)

        def serve():
            try:
                conn, _ = server_sock.accept()
                conn.recv(4096)
                conn.sendall(response)
                conn.close()
            except Exception:
                pass
            finally:
                server_sock.close()

        t = threading.Thread(target=serve, daemon=True)
        t.start()
        bridge = LoGuardBridge(sock_path=sock_path, auto_detect=False)
        return bridge, t, sock_path

    def test_block_ip_success(self):
        bridge, t, path = self._make_bridge_with_mock(
            {"ok": True, "ip": "1.2.3.4", "rule_id": 7}
        )
        result = bridge.block_ip("1.2.3.4", duration=3600, reason="TEST")
        t.join(timeout=2)
        assert result is True
        try: os.unlink(path)
        except FileNotFoundError: pass

    def test_block_ip_daemon_error(self):
        bridge, t, path = self._make_bridge_with_mock(
            {"ok": False, "error": "table full"}
        )
        result = bridge.block_ip("1.2.3.4")
        t.join(timeout=2)
        assert result is False
        try: os.unlink(path)
        except FileNotFoundError: pass

    def test_get_status_success(self):
        bridge, t, path = self._make_bridge_with_mock({
            "status": "running", "rules": 6,
            "connections": 42, "geoip_loaded": True, "ids_rules": 3,
        })
        result = bridge.get_status()
        t.join(timeout=2)
        assert result is not None
        assert result.get("status") == "running"
        try: os.unlink(path)
        except FileNotFoundError: pass


# ── Тесты calc_duration ────────────────────────────────────────────────────────

class TestCalcDuration:
    def test_none_returns_default(self):
        assert _calc_duration(None) == _DEFAULT_DURATION

    def test_future_timestamp(self):
        from datetime import datetime, timezone, timedelta
        future = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
        d = _calc_duration(future)
        assert 3500 <= d <= 3601

    def test_past_timestamp_returns_min(self):
        d = _calc_duration("2020-01-01T00:00:00+00:00")
        assert d == 60

    def test_invalid_timestamp(self):
        d = _calc_duration("not-a-date")
        assert d == _DEFAULT_DURATION

    def test_utc_z_format(self):
        from datetime import datetime, timezone, timedelta
        future = (
            datetime.now(timezone.utc) + timedelta(minutes=30)
        ).strftime("%Y-%m-%dT%H:%M:%SZ")
        d = _calc_duration(future)
        assert 1700 <= d <= 1801


# ── Тесты singleton ────────────────────────────────────────────────────────────

class TestSingleton:
    def test_get_bridge_returns_same(self):
        b1 = get_bridge()
        b2 = get_bridge()
        assert b1 is b2

    def test_configure_bridge(self):
        b = configure_bridge(sock_path="/tmp/test.sock", enabled=False)
        assert b.sock_path == "/tmp/test.sock"
        assert b.enabled is False

    def test_env_sock(self, monkeypatch):
        monkeypatch.setenv("LOGUARD_SOCK", "/tmp/custom.sock")
        b = get_bridge()
        assert b.sock_path == "/tmp/custom.sock"

    def test_env_disabled(self, monkeypatch):
        monkeypatch.setenv("LOGUARD_KERNEL_BLOCK", "false")
        monkeypatch.setenv("LOGUARD_SOCK", "/tmp/test.sock")
        b = get_bridge()
        assert b.enabled is False


# ── Тест enabled property ─────────────────────────────────────────────────────

class TestEnabledProperty:
    def test_toggle_enabled(self, bridge_no_sock):
        assert bridge_no_sock.enabled is True
        bridge_no_sock.enabled = False
        assert bridge_no_sock.enabled is False
        bridge_no_sock.enabled = True
        assert bridge_no_sock.enabled is True

    def test_disabled_skips_request(self, bridge_no_sock):
        bridge_no_sock.enabled = False
        assert bridge_no_sock.block_ip("5.5.5.5") is False


# ── Интеграционные тесты ──────────────────────────────────────────────────────

@pytest.mark.integration
class TestIntegration:
    """
    Запускать только если loguard-daemon запущен:
        pytest tests/test_bridge.py -v -m integration
    """

    SOCK = os.environ.get("LOGUARD_SOCK", "/var/run/loguard.sock")

    def _skip_if_no_daemon(self):
        if not os.path.exists(self.SOCK):
            pytest.skip("loguard-daemon not running")

    def test_status(self):
        self._skip_if_no_daemon()
        b = LoGuardBridge(self.SOCK)
        status = b.get_status()
        assert status is not None
        assert status.get("status") == "running"

    def test_block_unblock(self):
        self._skip_if_no_daemon()
        b = LoGuardBridge(self.SOCK)
        test_ip = "192.0.2.1"
        ok = b.block_ip(test_ip, duration=60, reason="pytest_test")
        assert isinstance(ok, bool)
        ok = b.unblock_ip(test_ip)
        assert isinstance(ok, bool)

    def test_stats(self):
        self._skip_if_no_daemon()
        b = LoGuardBridge(self.SOCK)
        stats = b.get_stats()
        assert stats is not None
        assert "rules" in stats

    def test_is_available(self):
        self._skip_if_no_daemon()
        b = LoGuardBridge(self.SOCK)
        assert b.is_available() is True